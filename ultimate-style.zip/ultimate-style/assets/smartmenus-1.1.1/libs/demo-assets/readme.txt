SmartMenus jQuery DOES NOT depend on any file in this folder.

This folder and its sub folders contain JavaScript and CSS files that are used just for the demo pages' layout and styling.